/**
 * FORMALLS - Interactive Script
 * Powers modals, WhatsApp simulator, ROI calculator, and UI interactions.
 */

document.addEventListener('DOMContentLoaded', () => {

  // Reveal comparison content as it enters the viewport.
  const comparisonSection = document.getElementById('comparison');
  if (comparisonSection && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const comparisonReveals = comparisonSection.querySelectorAll(
      '.comp-col-header, .comp-column-header, .comp-item-block'
    );
    comparisonReveals.forEach(element => element.classList.add('comparison-reveal'));
    comparisonSection.classList.add('motion-ready');

    if ('IntersectionObserver' in window) {
      const comparisonObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.15 });
      comparisonReveals.forEach(element => comparisonObserver.observe(element));
    } else {
      comparisonReveals.forEach(element => element.classList.add('is-visible'));
    }
  }

  // Reveal the How It Works heading, hub, and step cards in sequence.
  const howItWorksSection = document.getElementById('how-it-works');
  if (howItWorksSection && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const howItWorksReveals = howItWorksSection.querySelectorAll(
      '.hiw-header-group, .hiw-hub-wrapper, .hiw-card'
    );
    howItWorksReveals.forEach(element => element.classList.add('hiw-reveal'));
    howItWorksSection.classList.add('motion-ready');

    if ('IntersectionObserver' in window) {
      const howItWorksObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12 });
      howItWorksReveals.forEach(element => howItWorksObserver.observe(element));
    } else {
      howItWorksReveals.forEach(element => element.classList.add('is-visible'));
    }
  }

  // Add the same scroll reveal to the remaining page sections and footer.
  if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const revealSection = (sectionSelector, targetSelector) => {
      const section = document.querySelector(sectionSelector);
      if (!section) return;

      const targets = section.querySelectorAll(targetSelector);
      targets.forEach((element, index) => {
        element.classList.add('page-reveal');
        element.style.setProperty('--reveal-delay', `${Math.min(index, 5) * 65}ms`);
      });
      section.classList.add('reveal-enabled');

      if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries, activeObserver) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              activeObserver.unobserve(entry.target);
            }
          });
        }, { threshold: 0.12 });
        targets.forEach(element => observer.observe(element));
      } else {
        targets.forEach(element => element.classList.add('is-visible'));
      }
    };

    revealSection('#ecosystem', '.eco-header-wrap, .eco-card-item, .eco-bottom-banner, .eco-pillar-item');
    revealSection('#cta', '.cta-banner-bar');
    revealSection('#about', '.footer-brand-col, .footer-col, .footer-bottom-bar');
  }

  // ==============================================================
  // 1. MOBILE MENU TOGGLE
  // ==============================================================
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const navMenu = document.getElementById('navMenu');

  if (mobileMenuBtn && navMenu) {
    const setNavigationOpen = (isOpen) => {
      navMenu.classList.toggle('mobile-open', isOpen);
      mobileMenuBtn.classList.toggle('is-open', isOpen);
      mobileMenuBtn.setAttribute('aria-expanded', String(isOpen));
    };

    mobileMenuBtn.addEventListener('click', () => {
      setNavigationOpen(!navMenu.classList.contains('mobile-open'));
    });

    // Close menu when clicking any nav link
    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        setNavigationOpen(false);
      });
    });

    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') setNavigationOpen(false);
    });

    document.addEventListener('click', event => {
      if (!navMenu.contains(event.target) && !mobileMenuBtn.contains(event.target)) {
        setNavigationOpen(false);
      }
    });
  }

  // ==============================================================
  // 2. MODAL CONTROLS (BOOK DEMO, LOGIN, SEARCH, PERSONA)
  // ==============================================================
  const bookDemoModal = document.getElementById('bookDemoModal');
  const loginModal = document.getElementById('loginModal');
  const searchModal = document.getElementById('searchModal');
  const personaModal = document.getElementById('personaModal');

  const demoBtns = [
    document.getElementById('bookDemoNavBtn'),
    document.getElementById('heroBookDemoBtn'),
    document.getElementById('ctaBookDemoBtn'),
    document.getElementById('roiGetReportBtn')
  ];

  demoBtns.forEach(btn => {
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        openModal(bookDemoModal);
      });
    }
  });

  const loginBtn = document.getElementById('loginBtn');
  if (loginBtn) {
    loginBtn.addEventListener('click', () => openModal(loginModal));
  }

  const openSearchBtn = document.getElementById('openSearchBtn');
  if (openSearchBtn) {
    openSearchBtn.addEventListener('click', () => openModal(searchModal));
  }

  // Close buttons
  document.getElementById('closeDemoModalBtn')?.addEventListener('click', () => closeModal(bookDemoModal));
  document.getElementById('closeLoginModalBtn')?.addEventListener('click', () => closeModal(loginModal));
  document.getElementById('closeSearchModalBtn')?.addEventListener('click', () => closeModal(searchModal));
  document.getElementById('closePersonaModalBtn')?.addEventListener('click', () => closeModal(personaModal));
  document.getElementById('demoSuccessOkBtn')?.addEventListener('click', () => {
    closeModal(bookDemoModal);
    // Reset demo form state
    setTimeout(() => {
      document.getElementById('demoForm').style.display = 'flex';
      document.getElementById('demoSuccessState').style.display = 'none';
      document.getElementById('demoForm').reset();
    }, 300);
  });

  // Close modal when clicking outside card
  [bookDemoModal, loginModal, searchModal, personaModal].forEach(modal => {
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal(modal);
      });
    }
  });

  // Keyboard shortcut: Cmd+K / Ctrl+K opens search, Escape closes modals
  window.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      openModal(searchModal);
      document.getElementById('siteSearchInput')?.focus();
    }
    if (e.key === 'Escape') {
      [bookDemoModal, loginModal, searchModal, personaModal].forEach(closeModal);
    }
  });

  function openModal(modal) {
    if (!modal) return;
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeModal(modal) {
    if (!modal) return;
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  window.closeSearchModal = () => closeModal(searchModal);

  // ==============================================================
  // 3. BOOK A DEMO FORM SUBMISSION
  // ==============================================================
  const demoForm = document.getElementById('demoForm');
  const demoSuccessState = document.getElementById('demoSuccessState');

  if (demoForm && demoSuccessState) {
    demoForm.addEventListener('submit', (e) => {
      e.preventDefault();
      demoForm.style.display = 'none';
      demoSuccessState.style.display = 'block';
    });
  }

  // ==============================================================
  // 4. LOGIN PORTAL TABS & AUTO-FILL
  // ==============================================================
  const loginTabs = document.querySelectorAll('.login-tab');
  const loginEmail = document.getElementById('loginEmail');
  const autoFillBtn = document.getElementById('autoFillDemoLogin');

  loginTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      loginTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const role = tab.getAttribute('data-tab');
      if (role === 'mall') {
        loginEmail.value = 'admin@phoenixmalls.com';
      } else if (role === 'store') {
        loginEmail.value = 'store.manager@zara.in';
      } else if (role === 'cinema') {
        loginEmail.value = 'operations@pvrcinemas.com';
      }
    });
  });

  if (autoFillBtn && loginEmail) {
    autoFillBtn.addEventListener('click', () => {
      loginEmail.value = 'general.manager@selectcitywalk.com';
      document.getElementById('loginPassword').value = 'M@llOperations2026';
      autoFillBtn.textContent = '✓ Loaded Demo Credentials';
      setTimeout(() => {
        autoFillBtn.textContent = '⚡ Click here to auto-fill demo credentials';
      }, 2000);
    });
  }

  document.getElementById('loginForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('🎉 Welcome to Formalls Mall Operations Portal! Redirecting to dashboard...');
    closeModal(loginModal);
  });

  // ==============================================================
  // 5. SEARCH MODAL FILTER
  // ==============================================================
  const searchInput = document.getElementById('siteSearchInput');
  const searchResults = document.getElementById('searchResults');

  if (searchInput && searchResults) {
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      const items = searchResults.querySelectorAll('.search-result-item');
      items.forEach(item => {
        const text = item.textContent.toLowerCase();
        if (text.includes(query)) {
          item.style.display = 'flex';
        } else {
          item.style.display = 'none';
        }
      });
    });
  }

  // ==============================================================
  // 6. ECOSYSTEM PERSONA MODAL ("LEARN MORE")
  // ==============================================================
  const personaDetails = {
    'mall-owner': {
      title: 'Formalls for Mall Owners & Executives',
      badge: 'Mall Leadership',
      image: 'assets/eco_illu_mall.png?v=2',
      desc: 'Formalls delivers unified real-time visibility and operational control across your entire shopping destination.',
      items: [
        {
          title: 'Highest sales and more footfalls',
          desc: 'Drive tenant sales and increase overall mall footfall through real-time operational insights and analytics.'
        },
        {
          title: 'Campaign notifications to attract visitors',
          desc: 'Push centralized mall-wide announcements, flash sales, and festival promotions to shoppers on WhatsApp.'
        },
        {
          title: 'Visitor enquiry & assistance',
          desc: 'Direct shoppers to mall contact desks, helpline numbers, and resolve visitor inquiries seamlessly through WhatsApp.'
        },
        {
          title: 'Overall analysis of your mall',
          desc: 'Comprehensive executive analytics on daily footfall trends, tenant benchmarks, and operational KPIs.'
        }
      ]
    },
    'shop-owner': {
      title: 'Formalls for Retail Store Managers & Brands',
      badge: 'Retail & Brands',
      image: 'assets/eco_illu_shop.png?v=2',
      desc: 'Dedicated digital storefront to showcase products, publish offers, and engage shoppers directly.',
      items: [
        {
          title: 'Showcase products and get discovered',
          desc: 'Digital storefront accessible to every mall visitor directly on WhatsApp without requiring app downloads.'
        },
        {
          title: 'Create offers and attract more shoppers',
          desc: 'Launch flash deals, seasonal discounts, and limited-time promotions to drive immediate store visits.'
        },
        {
          title: 'Send targeted promotional campaigns',
          desc: 'Reach active mall shoppers with relevant, high-converting product announcements and new arrivals.'
        },
        {
          title: 'Connect with customers on WhatsApp',
          desc: 'Engage directly with interested shoppers inquiring about items, sizes, colors, and in-store availability.'
        }
      ]
    },
    'restaurant': {
      title: 'Formalls for Restaurants & Food Outlets',
      badge: 'Dining & Cafes',
      image: 'assets/eco_illu_restaurant.png?v=2',
      desc: 'Digital menus, dining promotions, and direct WhatsApp customer interaction for food court & dine-in outlets.',
      items: [
        {
          title: 'Digital menu showcase',
          desc: 'Showcase dishes, digital menus, price lists, and chef specials directly in chat.'
        },
        {
          title: 'Dining offers & combos',
          desc: 'Promote exclusive dining discounts, happy hour specials, and combo meals to hungry mall visitors.'
        },
        {
          title: 'Direct contact & chat',
          desc: 'Provide verified contact numbers, floor location, and instant WhatsApp chat for customer inquiries.'
        },
        {
          title: 'Outlet timings & information',
          desc: 'Keep visitors updated on opening hours, lunch & dinner timings, buffet schedules, and key outlet details.'
        }
      ]
    },
    'movies': {
      title: 'Formalls for Multiplexes & Cinema Operators',
      badge: 'Cinema & Multiplex',
      image: 'assets/eco_illu_movies.png?v=2',
      desc: 'Promote cinema releases, showtimes, and cinema snack catalogs directly to mall visitors on WhatsApp.',
      items: [
        {
          title: 'Live movie listings & times',
          desc: 'Keep shoppers informed with live movie schedules, daily screen timings, and upcoming releases.'
        },
        {
          title: 'Screen formats & audio info',
          desc: 'Clearly display IMAX, 4DX, Dolby Atmos, and special cinema format details for moviegoers.'
        },
        {
          title: 'New release promotions',
          desc: 'Push trailers, synopses, and upcoming blockbuster screenings directly to engaged shoppers.'
        },
        {
          title: 'Cinema snack menus & combos',
          desc: 'Showcase popcorn, beverage combos, and concession menus to boost pre-show F&B sales.'
        }
      ]
    },
    'funzone': {
      title: 'Formalls for Gaming Zones & Entertainment Centers',
      badge: 'Gaming & Arcades',
      image: 'assets/eco_illu_funzone.png?v=2',
      desc: 'Drive higher arcade visits, family footfall, and gaming engagement with frictionless WhatsApp discovery.',
      items: [
        {
          title: 'Attractions & games showcase',
          desc: 'Highlight top VR rides, bowling alleys, trampolines, and arcade games on WhatsApp.'
        },
        {
          title: 'Arcade offers & combos',
          desc: 'Promote arcade recharges, bonus credits, game combos, and seasonal game discounts.'
        },
        {
          title: 'Visitor rush & footfall insights',
          desc: 'Monitor visitor demand and peak times to optimize staffing during holidays and weekend rush.'
        },
        {
          title: 'Special events & activities',
          desc: 'Keep visitors updated on holiday gaming fests and interactive workshops.'
        }
      ]
    },
    'end-user': {
      title: 'Formalls for Mall Visitors & Shoppers',
      badge: 'Shoppers & Visitors',
      image: 'assets/eco_illu_visitors.png?v=2',
      desc: 'Everything inside the mall accessible instantly through official WhatsApp—no app installation required.',
      items: [
        {
          title: 'Find stores with smart indoor navigation',
          desc: 'Scan the QR code at any store entrance or kiosk to auto-detect your location and navigate anywhere.'
        },
        {
          title: 'Explore shops, restaurants and mall services',
          desc: 'Complete directory of retail brands, dining spots, restrooms, ATM, and parking bays.'
        },
        {
          title: 'Stay updated on offers, events and promotions',
          desc: 'Never miss flash deals, live mall events, weekend sales, or festival celebrations.'
        },
        {
          title: 'Explore menus and chat with stores on WhatsApp',
          desc: 'View food menus, browse retail catalogs, and chat directly with store managers without installing any app.'
        }
      ]
    }
  };

  window.showPersonaModal = (personaId) => {
    const data = personaDetails[personaId];
    if (!data) return;

    const contentDiv = document.getElementById('personaModalContent');
    contentDiv.innerHTML = `
      <div class="persona-modal-wrapper">
        <div class="persona-modal-header">
          <div class="persona-modal-illu-wrap">
            <img src="${data.image}" alt="${data.title}" class="persona-modal-illu">
          </div>
          <div class="persona-modal-header-text">
            <h3 class="persona-modal-title">${data.title}</h3>
            <p class="persona-modal-desc">${data.desc}</p>
          </div>
        </div>

        <div class="persona-modal-divider"></div>

        <div class="persona-modal-items">
          ${data.items.map(item => `
            <div class="persona-modal-item">
              <div class="persona-item-icon">
                <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="2.5 6 4.5 8 9.5 3"></polyline>
                </svg>
              </div>
              <div class="persona-item-content">
                <h4 class="persona-item-title">${item.title}</h4>
                <p class="persona-item-desc">${item.desc}</p>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    openModal(personaModal);
  };

  window.openEcosystemTab = (personaId) => {
    const ecoSection = document.getElementById('ecosystem');
    ecoSection?.scrollIntoView({ behavior: 'smooth' });
    setTimeout(() => {
      showPersonaModal(personaId);
    }, 600);
  };

  // ==============================================================
  // 7. INTERACTIVE WHATSAPP SIMULATOR
  // ==============================================================
  const simView = document.getElementById('whatsapp-simulator-view');
  const openSimBtn = document.getElementById('openSimulatorBtn');
  const closeSimBtn = document.getElementById('closeSimulatorBtn');
  const waChatBody = document.getElementById('waChatBody');
  const waUserInput = document.getElementById('waUserInput');
  const waSendBtn = document.getElementById('waSendBtn');
  const waTyping = document.getElementById('waTyping');

  function openSimulator() {
    simView.style.display = 'block';
    if (openSimBtn) {
      openSimBtn.classList.add('active-sim-open');
      const span = openSimBtn.querySelector('span');
      if (span) span.textContent = 'Hide Live Simulator';
    }
    setTimeout(() => {
      simView.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 50);
  }

  function closeSimulator() {
    simView.style.display = 'none';
    if (openSimBtn) {
      openSimBtn.classList.remove('active-sim-open');
      const span = openSimBtn.querySelector('span');
      if (span) span.textContent = 'Launch Live Simulator';
    }
    const calloutBar = document.querySelector('.flow-demo-callout-bar');
    if (calloutBar) {
      calloutBar.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function toggleSimulator() {
    if (simView.style.display === 'block') {
      closeSimulator();
    } else {
      openSimulator();
    }
  }

  if (openSimBtn && simView) {
    // Single click toggles open / close
    openSimBtn.addEventListener('click', () => {
      toggleSimulator();
    });

    // Double-click explicitly closes the simulator
    openSimBtn.addEventListener('dblclick', (e) => {
      e.preventDefault();
      closeSimulator();
    });
  }

  if (closeSimBtn && simView) {
    closeSimBtn.addEventListener('click', closeSimulator);
  }

  // Handle prompt pill clicks from simulator side panel
  document.addEventListener('click', (e) => {
    const promptBtn = e.target.closest('.sim-prompt-pill');
    if (promptBtn) {
      const promptText = promptBtn.getAttribute('data-prompt');
      if (promptText) {
        handleUserInteraction(promptText, 'custom');
      }
    }
  });

  // Handle preset choice buttons
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('wa-choice-btn')) {
      const replyType = e.target.getAttribute('data-reply');
      const btnText = e.target.textContent;
      handleUserInteraction(btnText, replyType);
    }
  });

  if (waSendBtn && waUserInput) {
    waSendBtn.addEventListener('click', submitCustomQuery);
    waUserInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') submitCustomQuery();
    });
  }

  function submitCustomQuery() {
    const text = waUserInput.value.trim();
    if (!text) return;
    waUserInput.value = '';
    handleUserInteraction(text, 'custom');
  }

  function handleUserInteraction(userText, type) {
    // 1. Append User Message
    const userMsg = document.createElement('div');
    userMsg.className = 'wa-msg wa-user-msg';
    userMsg.innerHTML = `
      <div class="msg-bubble">
        <p>${userText}</p>
        <div class="msg-meta">${getCurrentTime()} ✓✓</div>
      </div>
    `;
    waChatBody.appendChild(userMsg);
    waChatBody.scrollTop = waChatBody.scrollHeight;

    // 2. Show Typing Indicator
    if (waTyping) waTyping.style.display = 'flex';

    // 3. Bot Responds after realistic delay
    setTimeout(() => {
      if (waTyping) waTyping.style.display = 'none';
      const botMsg = document.createElement('div');
      botMsg.className = 'wa-msg wa-bot-msg';

      let replyHtml = '';
      const lower = userText.toLowerCase().trim();

      if (lower === 'hi' || lower === 'hello' || lower === 'hey' || lower.startsWith('hi ') || lower === 'menu' || lower === 'start') {
        replyHtml = `
          <div class="msg-bubble">
            <p>👋 <strong>Hi! Welcome to Nexus Mall on WhatsApp!</strong></p>
            <p>Here are your instant options:</p>
            <p>• <strong>Find Shops & Brands:</strong> Browse tenant catalogs & directories.<br>
            • <strong>Explore Offers:</strong> View exclusive flash discounts.<br>
            • <strong>Dining & Food Court:</strong> View menus, daily specials & offers.<br>
            • <strong>Cinema & Movies:</strong> Live movie showtimes.</p>
            <p style="margin-top:6px; font-size:0.75rem; color:#64748B;">📍 <em>Note:</em> To navigate indoors, scan the QR code present at any store to auto-detect your location and search where you want to go.</p>
            <div style="display:flex; flex-wrap:wrap; gap:6px; margin-top:8px;">
              <button class="wa-choice-btn" data-reply="offers">🔥 Explore Offers</button>
              <button class="wa-choice-btn" data-reply="stores">🏬 Store Directory</button>
              <button class="wa-choice-btn" data-reply="dining">🍔 Food Court</button>
              <button class="wa-choice-btn" data-reply="movies">🎬 Movies</button>
            </div>
            <div class="msg-meta">${getCurrentTime()} ✓✓</div>
          </div>
        `;
      } else if (type === 'offers' || lower.includes('offer') || lower.includes('deal')) {
        replyHtml = `
          <div class="msg-bubble">
            <p>🔥 <strong>Exclusive Today-Only Mall Deals:</strong></p>
            <p>• <strong>Ilika by Vividhity:</strong> Flat 15% Off on Pure Linen & Handloom Sarees.<br>
            • <strong>ZARA (Ground Floor):</strong> Flat 40% Off End of Season Sale.<br>
            • <strong>H&M (1st Floor):</strong> Buy 2 Get 1 Free on Spring Apparel.<br>
            • <strong>Starbucks:</strong> Free tall upgrade with code <code>FORMALLS26</code></p>
            <p style="margin-top:6px; font-size:0.75rem; color:#0066FF;">⚡ Show this WhatsApp message at counter to redeem.</p>
            <div class="msg-meta">${getCurrentTime()} ✓✓</div>
          </div>
        `;
      } else if (lower.includes('map') || lower.includes('navigate') || lower.includes('direction') || lower.includes('wayfinding') || lower.includes('qr')) {
        replyHtml = `
          <div class="msg-bubble">
            <p>📍 <strong>Indoor Wayfinding & Navigation:</strong></p>
            <p>Store navigation and interactive maps are <strong>not on WhatsApp</strong>.</p>
            <p>Instead, <strong>scan the QR code present at any store</strong> with your phone camera:</p>
            <p>1. It automatically identifies <strong>where you are right now</strong>.<br>
            2. Simply search <strong>where you want to go</strong> to get turn-by-turn indoor routing!</p>
            <div class="msg-meta">${getCurrentTime()} ✓✓</div>
          </div>
        `;
      } else if (type === 'stores' || lower.includes('store') || lower.includes('brand') || lower.includes('ilika') || lower.includes('saree') || lower.includes('catalog') || lower.includes('zara')) {
        replyHtml = `
          <div class="msg-bubble wa-media-bubble">
            <div class="wa-media-img-wrap" style="background:#FFFFFF; padding:6px;">
              <img src="assets/ilika-brand-card.png" alt="Ilika by Vividhity" class="wa-media-img" style="max-height:160px;">
            </div>
            <div class="wa-media-caption">
              <p>🏬 <strong>Ilika by Vividhity</strong> (Ground Floor, Unit 104)</p>
              <p>• <strong>Specialty:</strong> Just plain sarees, Pure Linen sarees, Kasavu Sarees, Handloom along with accessories.<br>
              • <strong>Other Brands:</strong> ZARA (Atrium Gate 2), Apple Store (1st Floor Wing B), Sephora (Ground Floor).</p>
              <p style="margin-top:6px; font-size:0.75rem; color:#475569;">📍 <em>Indoor Wayfinding:</em> Scan QR outside any store to auto-detect your location and navigate here.</p>
            </div>
            <div class="msg-meta">${getCurrentTime()} ✓✓</div>
          </div>
        `;
      } else if (type === 'dining' || lower.includes('food') || lower.includes('restaurant') || lower.includes('menu')) {
        replyHtml = `
          <div class="msg-bubble">
            <p>🍽️ <strong>Dining & Food Court:</strong></p>
            <p>• <strong>Punjab Grill:</strong> North Indian specialty — View menu & specials<br>
            • <strong>YouMee Asian:</strong> 15% discount for mall shoppers<br>
            • <strong>Food Court:</strong> 22 counters open today</p>
            <div style="margin-top:8px; padding-top:8px; border-top:1px solid #E2E8F0;">
              <p style="font-size:0.75rem; color:#475569; margin-bottom:6px;">📖 <em>Browse catalogs & contact restaurants directly on WhatsApp:</em></p>
              <button class="wa-choice-btn" style="margin-top:4px;" onclick="alert('Viewing Punjab Grill digital menu on WhatsApp')">📖 View Punjab Grill Menu & Offers</button>
            </div>
            <div class="msg-meta">${getCurrentTime()} ✓✓</div>
          </div>
        `;
      } else if (type === 'movies' || lower.includes('movie') || lower.includes('cinema') || lower.includes('pvr')) {
        replyHtml = `
          <div class="msg-bubble">
            <p>🍿 <strong>PVR IMAX (Level 4) Now Showing:</strong></p>
            <p>• <em>Dune: Part Two (IMAX 3D)</em> — 3:45 PM | 7:15 PM<br>
            • <em>Kung Fu Panda 4</em> — 4:10 PM | 6:30 PM<br>
            • <em>Oppenheimer</em> — 8:40 PM</p>
            <div style="margin-top:8px; padding-top:8px; border-top:1px solid #E2E8F0;">
              <p style="font-size:0.76rem; color:#475569; margin-bottom:6px;">🎟️ <em>Seats & instant ticketing on BookMyShow:</em></p>
              <a href="https://in.bookmyshow.com" target="_blank" rel="noopener noreferrer" class="wa-bookmyshow-btn">
                <span>Book Tickets on BookMyShow</span>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
              </a>
            </div>
            <div class="msg-meta">${getCurrentTime()} ✓✓</div>
          </div>
        `;
      } else if (type === 'parking' || lower.includes('park') || lower.includes('car')) {
        replyHtml = `
          <div class="msg-bubble">
            <p>🅿️ <strong>Smart Parking Assistant:</strong></p>
            <p>• <strong>Basement 1:</strong> 84 slots available<br>
            • <strong>Basement 2 (EV Fast Chargers):</strong> 12 chargers free</p>
            <div class="msg-meta">${getCurrentTime()} ✓✓</div>
          </div>
        `;
      } else {
        replyHtml = `
          <div class="msg-bubble">
            <p>🤖 I've noted your request for: "<strong>${escapeHtml(userText)}</strong>".</p>
            <p>Our Mall Information Desk on Ground Floor has also been notified. Would you like to view our store directory or today's top offers?</p>
            <div class="msg-meta">${getCurrentTime()} ✓✓</div>
          </div>
        `;
      }

      botMsg.innerHTML = replyHtml;
      waChatBody.appendChild(botMsg);
      waChatBody.scrollTop = waChatBody.scrollHeight;
    }, 750);
  }

  function getCurrentTime() {
    const now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    return `${hours}:${minutes} ${ampm}`;
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // ==============================================================
  // 8. FAQ ACCORDION
  // ==============================================================
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      faqItems.forEach(i => i.classList.remove('active'));
      if (!isActive) item.classList.add('active');
    });
  });

});
